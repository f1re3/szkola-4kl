const INE = document.querySelector('h2')

INE.addEventListener('click', (event)=>{
    INE.innerHTML='Daniel Sobiech'
})